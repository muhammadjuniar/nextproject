// const Test = () => {
//     return (
//         <h1>Hello</h1>
//     )
// }

// export default Test

export default function Test() {
    return (
        <h1>Hello</h1>
    )
}